package ssg.com.a.dao;

import ssg.com.a.dto.MemberDto;

public interface MemberDao {

	int idcheck(String id);
	
	int addmember(MemberDto dto);
	
	MemberDto login(MemberDto dto);
	
	MemberDto naverLogin(String email);
}
